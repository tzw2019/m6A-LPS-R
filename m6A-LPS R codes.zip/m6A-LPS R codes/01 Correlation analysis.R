

library(limma)
setwd("")     

corFilter=0.5          
pvalueFilter=0.001       

rt = read.table("lncRNA expression.txt",header=T,sep="\t",check.names=F)
rt=as.matrix(rt)
rownames(rt)=rt[,1]
exp=rt[,2:ncol(rt)]
dimnames=list(rownames(exp),colnames(exp))
lncRNA=matrix(as.numeric(as.matrix(exp)),nrow=nrow(exp),dimnames=dimnames)
lncRNA=avereps(lncRNA)
lncRNA=lncRNA[rowMeans(lncRNA)>0.5,]
group=sapply(strsplit(colnames(lncRNA),"\\-"),"[",4)
group=sapply(strsplit(group,""),"[",1)
group=gsub("2","1",group)
lncRNA=lncRNA[,group==0]


rt = read.table("m6A-related gene expression.txt",header=T,sep="\t",check.names=F)
rt=as.matrix(rt)
rownames(rt)=rt[,1]
exp=rt[,2:ncol(rt)]
dimnames=list(rownames(exp),colnames(exp))
m6AGene=matrix(as.numeric(as.matrix(exp)),nrow=nrow(exp),dimnames=dimnames)
m6AGene=avereps(m6AGene)
m6AGene=m6AGene[rowMeans(m6AGene)>0.5,]
group=sapply(strsplit(colnames(m6AGene),"\\-"),"[",4)
group=sapply(strsplit(group,""),"[",1)
group=gsub("2","1",group)
immuneGene=m6AGene[,group==0]

outTab=data.frame()
for(i in row.names(lncRNA)){
	  if(sd(lncRNA[i,])>0.5){
			  for(j in row.names(m6AGene)){
				     x=as.numeric(lncRNA[i,])
				     y=as.numeric(m6AGene[j,])
				     corT=cor.test(x,y)
				     cor=corT$estimate
				     pvalue=corT$p.value
				     if((cor>corFilter) & (pvalue<pvalueFilter)){
				         outTab=rbind(outTab,cbind(m6AGene=j,lncRNA=i,cor,pvalue,Regulation="postive"))
				     }
				     if((cor< -corFilter) & (pvalue<pvalueFilter)){
				         outTab=rbind(outTab,cbind(m6AGene=j,lncRNA=i,cor,pvalue,Regulation="negative"))
				     }
			  }
		}
}
write.table(file="corResult.txt",outTab,sep="\t",quote=F,row.names=F)        
m6ALncRNA=unique(outTab[,"lncRNA"])
m6ALncRNAexp=lncRNA[m6ALncRNA,]
m6ALncRNAexp=rbind(ID=colnames(m6ALncRNAexp),m6ALncRNAexp)
write.table(m6ALncRNAexp,file="m6ALncRNAexp.txt",sep="\t",quote=F,col.names=F)


