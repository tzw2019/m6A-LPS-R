
setwd("")

library(rms)
library(foreign)
library(survival)

nomogram<-read.table("Nomogram.txt",header=T,sep="\t")

cox <- cph(Surv(OS,Censor) ~ age + grade + risk,surv=T,x=T, y=T,time.inc = 1*365*1,data=seer) 
cal <- calibrate(cox1, cmethod="KM", method="boot", u=1*365*1, m= 118, B=476)

plot(cal,lwd=2,lty=1,
     errbar.col=c(rgb(0,118,192,maxColorValue=255)),
     xlim=c(0.85,1),ylim=c(0.7,1),
     xlab="Nomogram-Predicted Probability of 1-Year OS",
     ylab="Actual 1-Year OS (proportion)",
     col=c(rgb(192,98,83,maxColorValue=255)))
