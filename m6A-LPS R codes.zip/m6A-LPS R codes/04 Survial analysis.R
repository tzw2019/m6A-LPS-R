

setwd("")  

library(survival)

rt=read.table("Survival input.txt",header=T,sep="\t")
diff=survdiff(Surv(OS, Censor) ~ group,data = rt)
pValue=1-pchisq(diff$chisq,df=1)
pValue=signif(pValue,4)
pValue=format(pValue, scientific = TRUE)
fit <- survfit(Surv(OS, Censor) ~ group, data = rt)
summary(fit)   
pdf(file="survivalTrain.pdf",width=5.5,height=5)
plot(fit, 
     lwd=2,
     col=c("red","blue"),
     xlab="Time (year)",
     ylab="Survival rate",
     main=paste("Survival curve (p=", pValue ,")",sep=""),
     mark.time=T)
legend("topright", 
       c("high expression", "low expression"),
       lwd=2,
       col=c("red","blue"))
dev.off()
