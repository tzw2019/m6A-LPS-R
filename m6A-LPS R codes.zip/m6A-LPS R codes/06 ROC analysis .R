library(survival)
library(timeROC)
setwd("")
data<-read.table("ROC input.txt",header=T,sep="\t")
predict_1_year<- 1*365
predict_3_year<- 3*365
predict_5_year<- 5*365

ROC1<-timeROC(T=data$OS,delta=data$Censor,
             marker=data$riskscore,cause=1,
             weighting="marginal",
             times=c(predict_5_year),ROC=TRUE)
ROC2<-timeROC(T=data$OS,delta=data$Censor,
              marker=data$age,cause=1,
              weighting="marginal",
              times=c(predict_5_year),ROC=TRUE)
ROC3<-timeROC(T=data$OS,delta=data$Censor,
              marker=data$grade,cause=1,
              weighting="marginal",
              times=c(predict_5_year),ROC=TRUE)
ROC4<-timeROC(T=data$OS,delta=data$Censor,
              marker=data$Nomogram,cause=1,
              weighting="marginal",
              times=c(predict_5_year),ROC=TRUE)

pdf("ROC plot.pdf")
plot(ROC1,time=predict_5_year,col="blue",title=FALSE,lwd=3)
plot(ROC2,time=predict_5_year,col="yellow",add=TRUE,title=FALSE,lwd=3)
plot(ROC3,time=predict_5_year,col="red",add=TRUE,title=FALSE,lwd=3)
plot(ROC4,time=predict_5_year,col="green",add=TRUE,title=FALSE,lwd=3)
legend("bottomright",
       c(paste("Risk score: ",round(ROC1$AUC[2],3)),
         paste("Age: ",round(ROC2$AUC[2],3)),
         paste("Grade: ",round(ROC3$AUC[2],3)),
       paste("Nomogram: ",round(ROC4$AUC[2],3))),col=c("blue","yellow","red","green"),lwd=3)
dev.off()


