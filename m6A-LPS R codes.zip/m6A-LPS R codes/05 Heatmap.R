
setwd("")      
rt=read.table("Expression.txt",sep="\t",header=T,row.names=1,check.names=F)   
outpdf="heatmap.pdf"

library(pheatmap)
library(RColorBrewer)
library(colorspace)
Type=read.table("Clinical.txt",sep="\t",header=T,row.names=1,check.names=F)
Type=Type[order(Type$Riskscore),]
rt=rt[,row.names(Type)]

pdf(outpdf,height=12,width=16)
pheatmap(rt, border=T,annotation=Type, cellwidth = 3, cellheight = 25, cluster_rows = T,
         color = colorRampPalette(c("blue", "white", "orange"))(50),
         border_color = "white",
         annotation_height=7,
         annotation_colors = list(
           Riskscore = c("white", "black"), 
           Grade = c(WHOII = "lightcyan2", WHOIII = "yellow2", WHOIV ="orange"),
           IDH = c(Mutant = "gray" , Wildtype = "black",NA="white"),
           1p/19q = c(Codel ="skyblue" , Noncodel ="orange" , NA="white")),
         cluster_cols =F,
         fontsize=10,
         fontsize_row=15,
         scale="row",
         show_colnames=F,
         fontsize_col=3)
dev.off()


