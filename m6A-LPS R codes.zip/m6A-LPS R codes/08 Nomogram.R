
library(rms)
library(foreign)
library(survival)
setwd("")
nomogram<-read.table("Nomogram input.txt",header=T,sep="\t")

ddist <- datadist(nomogram)
options(datadist='ddist')

cox <- cph(Surv(OS,Censor) ~age + grade + riskscore ,surv=T,x=T, y=T,data=nomogram) 

surv <- Survival(cox)
sur_1_year<-function(x)surv(365*1,lp=x)
sur_3_year<-function(x)surv(365*3,lp=x)
sur_5_year<-function(x)surv(365*5,lp=x)
nom_sur <- nomogram(cox,fun=list(sur_1_year,sur_3_year,sur_5_year),lp= F,funlabel=c('1-Year Survival','3-Year Survival','5-Year survival'),maxscale=100,fun.at=c('0.9','0.8','0.7','0.6','0.5','0.4','0.3','0.2','0.1'))

pdf("nomogram plot.pdf")
plot(nom_sur,xfrac=0.25)
dev.off()

